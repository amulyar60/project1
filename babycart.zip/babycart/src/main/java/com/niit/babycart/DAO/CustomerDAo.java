package com.niit.babycart.DAO;

import java.util.List;

import com.niit.babycart.model.Customer;


	public interface CustomerDAo {
		 public void addCustomer (Customer customer);
         public List<Customer> getAllcustomers();
		 public Customer getCustomerByID(int Customer);
		 public void getCustomerByUsername1 (String username);

	}


