package com.niit.babycart.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.babycart.model.Product;
import com.niit.babycart.service.Productservice;
   @Service
   public abstract class ProductserviceImpl implements Productservice {
		
		private Product ProductDAO;

		public void setProductDAO(Product ProductDAO) {
			this.ProductDAO = ProductDAO;
		}

		@Transactional
		public void addProduct(Product product) {
			//this.ProductDAO.addProduct(product);
		}

		@Transactional
		public void updateProduct(Product product)
		{
			//this.ProductDAO.updateProduct(product);
		}


		@Transactional
		//public Product getProductById(int id) {
			//return this.ProductDAO.getProductById(id);
		//}

		//@Transactional
		public void removeProduct(int id) {
			//this.ProductDAO.removeProduct(id);
		}
   }
	