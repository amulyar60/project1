package com.niit.babycart.DAOImpl;

import java.util.List;


import org.h2.engine.User;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.babycart.DAO.CustomerDAo;
import com.niit.babycart.model.Customer;
import com.niit.babycart.model.Users;
@Repository
@Transactional
public abstract class CustomerDAOImpl implements CustomerDAo{

    @Autowired
    private SessionFactory sessionFactory;

   // public void addCustomer(Customer customer) 
  
        //{Session session = sessionFactory.getCurrentSession()
        

        /*&customer.getBillingAddress().setCustomer(customer);
        customer.getShippingAddress().setCustomer(customer);

        session.saveOrUpdate(customer);
        session.saveOrUpdate(customer.getBillingAddress());
        session.saveOrUpdate(customer.getShippingAddress());*/

      /*  User newUser = new User();
        newUser.setObjectName(customer.getUserName());
        newUser.setPassword(customer.getPassword());
        newUser.setEnabled(true);
        newUser.setCustomerId(customer.getCustomerID());
    }*/
    public Customer getCustomerById (int customerId) {
        Session session = sessionFactory.getCurrentSession();
        return (Customer) session.get(Customer.class, customerId);
    }

    public List<Customer> getAllCustomers() {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from Customer");
        List<Customer> customerList = query.list();

        return customerList;
    }

    public Customer getCustomerByUsername (String username) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from Customer where username = ?");
        query.setString(0, username);

        return (Customer) query.uniqueResult();
    }
}