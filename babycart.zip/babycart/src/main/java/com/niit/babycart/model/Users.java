package com.niit.babycart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="User")
public class Users {
	 @Id
	 @Column(name = "UserID")
	 private Integer UserID;
	 
	 @Column(name = "UserName")
	 private String UserName;
	 
	 @Column(name = "password")
	 private String password;
	 
	 public Integer getUserID() {
		return UserID;
	}

	public void setUserID(Integer userID) {
		UserID = userID;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public Integer getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(Integer customerID) {
		CustomerID = customerID;
	}

	@Column(name = "enabled")
	 private String enabled;
	 
	 @Column(name = "CustomerID")
	 private Integer CustomerID;

}
