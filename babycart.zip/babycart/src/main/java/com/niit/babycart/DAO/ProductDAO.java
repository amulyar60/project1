package com.niit.babycart.DAO;

import java.util.List;

import com.niit.babycart.model.Product;


	public interface ProductDAO {
		 
		 public void addProduct(Product product);
		 public List<Product> getproductList();
		 public Product getproductById(int id);
		 public void deleteProduct(Product product);

		 
		}
	


